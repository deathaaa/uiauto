# -*- coding: utf-8 -*-
__author__ = 'litang.wang'


class PLATFORM:
    def __init__(self):
        pass

    PC_CHROME = 'pc_chrome'
    PC_IE = 'pc_ie'
    PC_FIREFOX = 'pc_firefox'
    TOUCH = 'touch'
    ANDROID = 'android'
    IOS = 'ios'
    CUSTOM = 'custom'
