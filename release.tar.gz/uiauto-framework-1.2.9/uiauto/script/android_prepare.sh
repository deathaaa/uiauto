#!/usr/bin/env bash
pkill -9 node
pkill -9 adb
sleep 2
#adb kill-server
#sleep 2
#adb start-server
#sleep 2