# -*- coding: utf-8 -*-
__author__ = 'litang.wang'


class CaseType:
    def __init__(self):
        pass

    NORMAL = 'normal'
    ORDERLY = 'orderly'
    CUSTOM = 'custom'
