# -*- coding: utf-8 -*-

__author__ = 'litang.wang'


class Cases:
    def __init__(self, case_class, case_list, prefix_case_list, case_type):
        self.case_class = case_class
        self.case_list = case_list
        self.prefix_case_list = prefix_case_list
        self.case_type = case_type
